# R37
WARNING : During the decryption process, a HTTP server is created on the 8888 port. Check that nothing is on this port before launch the script !

R37 is a crypt and decrypt script that is created by __R3tr0(also known as his oldname Camittseul)

Copyright - All rights reserved
